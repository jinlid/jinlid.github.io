import eventlet
eventlet.monkey_patch()
from PostgreTest.main import create_app, socketio

app = create_app()
if __name__ == '__main__':
    socketio.run(app, host="192.168.137.129", port=9096, debug=True)