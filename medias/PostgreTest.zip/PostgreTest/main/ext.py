from sqlalchemy import desc
from PostgreTest.main.models import db, Task
from PostgreTest.main.utils import getpages


class TaskService:
    @staticmethod
    def create_task(data):
        new_task = Task(
            task_id=data['task_id'],
            repository=data['repository'],
            status=data['status'],
        )
        db.session.add(new_task)
        db.session.commit()
        return new_task

    @staticmethod
    def delete_task(task_id):
        task = Task.query.get(task_id)
        if task:
            db.session.delete(task)
            db.session.commit()
            return True
        return False

    @staticmethod
    def update_task(task_id, return_code=None, status=None, detail_info=None, updated_at=None):
        task = Task.query.get(task_id)
        if task:
            if return_code is not None:
                task.return_code = return_code
            if status:
                task.status = status
            if detail_info:
                task.detail_info = detail_info
            if updated_at:
                task.updated_at = updated_at
            db.session.commit()
            return task
        return None

    @staticmethod
    def get_task(task_id):
        task = Task.query.get(task_id)
        return task

    @staticmethod
    def get_tasks(page=1, per_page=10, status=None):
        tasks = Task.query.order_by(desc(Task.created_at)).paginate(page=page, per_page=per_page, error_out=False)
        # # 使用 __dict__ 获取字典表示，排除内部的 SQLAlchemy 特殊字段（如 _sa_instance_state）
        # task_list = [task.__dict__ for task in tasks.items]
        # # 移除 SQLAlchemy 内部管理的字段 _sa_instance_state
        # for task in task_list:
        #     task.pop('_sa_instance_state', None)
        # 使用 to_dict() 方法将每个 Task 对象转换为字典
        task_list = [task.to_dict() for task in tasks.items]
        data = {
            "content_list": task_list,
            "page_list": getpages(page, tasks.total),
            "cur_page": str(page),
            "content_total": str(tasks.total),
            "view_name" : "myview.imageManager",
        }
        return data
