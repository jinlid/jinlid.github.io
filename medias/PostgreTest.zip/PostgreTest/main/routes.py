import logging, os, docker
from flask import request, render_template, jsonify, send_from_directory, Blueprint
from datetime import datetime
from flask import current_app
from PostgreTest.main import socketio
from PostgreTest.main.utils import *
from PostgreTest.main.ext import TaskService

logger = logging.getLogger(__name__)
logging.basicConfig(format='%(asctime)s %(message)s', level=logging.INFO)
myview = Blueprint("myview", __name__)
BASE_DIR = os.path.abspath(os.path.dirname(__file__))

# 主页
@myview.route("/")
def index():
    return render_template("index.html")


@myview.route("/<name>", methods=['GET'])
def render(name):
    return render_template(name + ".html")

@myview.route('/imageManager', methods=['GET'])
def imageManager():
    # 使用 request.args.get() 来获取 URL 中的查询参数
    page = int(request.args.get('page', 1))  # 默认第一页
    data = TaskService.get_tasks(page)
    return render_template("imageManager.html", **data)

def long_running_task(data, app, socketio):
    # 构建参数
    version = data['version']
    repository = data['repository']
    mirror_url = data['mirror_url']
    # 构建命令的参数
    build_args = {
        'URL': mirror_url,
        'PGVERSION': version
    }
    # 用来收集构建日志的列表
    build_logs = []
    task_id = data['task_id']
    try:
        image, logs = client.images.build(
            path=BASE_DIR + '/scripts',
            tag=repository,
            buildargs=build_args,
            rm=True,
        )
        status = 'Succeeded'
        # 遍历日志输出
        for line in logs:
            if 'stream' in line:
                stream = line['stream'].strip() # 去掉可能的前后空格
                if stream:  # 只有非空内容才打印
                    build_logs.append(line['stream'].strip())
            elif 'error' in line:
                logger.error(f"Error: {line['error']}") # 如果有错误，打印错误信息
        with app.app_context():
            TaskService.update_task(task_id=task_id, status=status, detail_info="\n".join(build_logs))
        socketio.emit('task_update', {'task_id': task_id, 'status': status, 'detail_info': "\n".join(build_logs),
                                      'updated_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S')})
    except docker.errors.DockerException as e:
        error_message = str(e)  # 将错误信息转换为字符串
        logger.error(f"Error during image build: {error_message}")
        status = 'Failed'
        with app.app_context():
            TaskService.update_task(task_id=task_id, status=status, detail_info=error_message)
        socketio.emit('task_update', {'task_id': task_id, 'status': status, 'detail_info': error_message,
                                      'updated_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S')})

@socketio.on('page_loaded')
def task_update(data):
    # 更新任务状态为运行中
    status = 'Running'
    app = current_app._get_current_object()
    task_id = data['task_id']
    with app.app_context():
        TaskService.update_task(task_id=task_id, status=status)
    socketio.emit('task_update',
                  {'task_id': task_id, 'status': status, 'updated_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S')})
    # 处理接收到的数据并启动后台任务
    socketio.start_background_task(long_running_task, data, app, socketio)

@myview.route('/addImage', methods=['GET', 'POST'])
def addImage():
    data = request.get_json()  # 使用 json.loads 解析数据
    logger.debug(data)
    create_data = {
        'task_id': data['task_id'],
        'repository': data['repository'],
        'status': 'Pending',
    }
    TaskService.create_task(create_data)
    page = int(request.args.get('page', 1))  # 默认第一页
    data = TaskService.get_tasks(page)
    return jsonify(data=data), 202


@myview.route('/imageList', methods=['GET'])
def imageList():
    # 使用 request.args.get() 来获取 URL 中的查询参数
    page = int(request.args.get('page', 1))  # 默认第一页
    data = get_image_list(page)
    return render_template("imageList.html", **data)


@myview.route('/dropImage', defaults={'page': '1'}, methods=['GET', 'POST'])
def dropImage(page):
    # 获取 POST 请求中的纯文本数据
    image_id = request.data.decode('utf-8')
    try:
        client.images.remove(image_id, force=True)
    except docker.errors.DockerException as e:
        error_message = str(e)  # 将错误信息转换为字符串
        return jsonify({"error": error_message}), 400
    data = get_image_list(page)
    return jsonify(data=data)


@myview.route('/getImageVersions', methods=['GET', 'POST'])
def getImageVersions():
    data = get_images()
    return jsonify(data)


@myview.route('/containerManager', methods=['GET'])
def containerManager():
    # 使用 request.args.get() 来获取 URL 中的查询参数
    page = int(request.args.get('page', 1))  # 默认第一页
    data = get_container_list(page)
    return render_template("containerManager.html", **data)


@myview.route('/addContainer', methods=['GET', 'POST'])
def addContainer():
    data = request.get_json()
    image = data['image']
    container_name = data['container']
    volume = "/opt"
    network_name = get_container_network()
    ipv4_address = get_random_free_ipv4_address()
    # 使用 EndpointConfig 配置容器的网络端点
    endpoint_config = docker.types.EndpointConfig(
        version="1.45",             # 添加 version 参数
        ipv4_address=ipv4_address   # 设置固定 IP 地址
    )
    # 配置 networking_config
    networking_config = {
        network_name: endpoint_config  # 指定网络名和端点配置
    }
    port = get_random_free_port()
    try:
        container = client.containers.run(
            image=image,
            command="sleep infinity",                                       # 运行容器并保持其运行状态
            name=container_name,                                            # 设置容器名称
            hostname=container_name,                                        # 设置容器主机名
            network=network_name,                                           # 设置网络
            networking_config=networking_config,                            # 设置ip
            ports={'5432/tcp': (f'{remote_ip}', port)},                     # 映射端口
            volumes={volume: {'bind': "/opt", 'mode': 'rw'}},               # 挂载卷
            network_mode=None,                                              # 允许指定网络
            detach=True,                                                    # 在后台运行容器
        )
    except docker.errors.DockerException as e:
        error_message = str(e)  # 将错误信息转换为字符串
        return jsonify({"error": error_message}), 400
    data = get_container_list('1')
    return jsonify(data=data)


@myview.route('/dropContainer', defaults={'page': '1'}, methods=['GET', 'POST'])
def dropContainer(page):
    # 获取 POST 请求中的纯文本数据
    container_id = request.data.decode('utf-8')  # 解码为字符串
    try:
        container = client.containers.get(container_id)
        container.remove(force=True)
    except docker.errors.DockerException as e:
        error_message = str(e)  # 将错误信息转换为字符串
        return jsonify({"error": error_message}), 400
    data = get_container_list(page)
    return jsonify(data=data)



@myview.route('/partiallTest', methods=['GET', 'POST'])
def partiallTest():
    data = get_container_list('1')
    return render_template("partiallTest.html", **data)


@myview.route('/tpccReport/<index>/report.html')
def serve_report(index):
    # 指定文件目录
    base_directory = '/opt/tpccReport'
    report_path = os.path.join(base_directory, index, 'report.html')
    # 检查文件是否存在
    print(os.path.join(base_directory, index))
    if os.path.exists(report_path):
        return send_from_directory(os.path.join(base_directory, index), 'report.html')
    else:
        return "File not found", 404