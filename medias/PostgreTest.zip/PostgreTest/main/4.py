from flask import Flask
from flask_socketio import SocketIO
import time
import threading

app = Flask(__name__)
socketio = SocketIO(app)


# 假设这是主备库的安装和同步过程
def install_database(database_info, database_type, event, socketio):
    """模拟数据库安装任务"""
    print(f"{database_type} 安装开始: {database_info}")
    time.sleep(5)  # 模拟安装操作，实际操作中应该是具体的安装步骤
    print(f"{database_type} 安装完成: {database_info}")

    if database_type == '主库':
        # 主库安装完成后，触发事件，告知备库任务可以同步启动
        socketio.emit('main_db_installed', {'status': '主库已启动'})
    else:
        # 备库等待主库启动
        socketio.emit('waiting_for_main_db', {'status': '备库等待主库同步'})
        socketio.sleep(0)  # 允许任务在等待中切换
        print(f"{database_type} 启动完成，开始同步主库数据并执行 build")
        # 这里模拟备库的 build 操作
        time.sleep(3)  # 模拟 build 操作
        print(f"{database_type} build 操作完成")


def main_task(data1, data2, socketio):
    """主线程控制同步任务"""
    # 先启动主库和备库的安装任务
    socketio.start_background_task(install_database, data1, '主库', socketio)
    socketio.start_background_task(install_database, data2, '备库', socketio)

    # 等待主库安装完成的事件，然后启动备库的 build 操作
    def on_main_db_installed(message):
        print("收到事件：主库已启动，备库开始同步并执行 build")
        # 在收到主库启动事件后，备库开始同步并执行 build
        socketio.emit('build_started', {'status': '备库开始同步主库并执行 build'})

    socketio.on_event('main_db_installed', on_main_db_installed)


# 数据
data1 = {'db_info': '主库信息'}
data2 = {'db_info': '备库信息'}

# 启动主备库安装和同步任务
socketio.start_background_task(main_task, data1, data2, socketio)

if __name__ == '__main__':
    socketio.run(app, debug=True)
