import ipaddress, math, json, socket, random, docker
from dateutil import parser
per_page = 10

remote_ip = '192.168.137.129'
client = docker.DockerClient(base_url=f"tcp://{remote_ip}:2375")

def get_container_network():
    network_name = "postgrenetwork"
    # 尝试获取网络
    try:
        # 查找指定名称的网络
        network = client.networks.get(network_name)
    except docker.errors.NotFound:
        # 如果网络不存在，则创建该网络
        network = client.networks.create(
            network_name,
            driver="bridge",
            ipam=docker.types.IPAMConfig(
                pool_configs=[docker.types.IPAMPool(subnet="172.19.1.0/24")]
            )
        )
    return network_name
# def get_remote_result(cmd):
#     try:
#         client = paramiko.SSHClient()
#         client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
#         client.connect('192.168.137.129',
#                        username='root',
#                        password='root')
#         _, stdout, stderr = client.exec_command(cmd)
#         stdout_result = stdout.read().decode('utf-8')
#         stderr_result = stderr.read().decode('utf-8')
#         exit_code = stdout.channel.recv_exit_status()
#         client.close()
#         return stdout_result, stderr_result, exit_code
#     except Exception as e:
#         print(f"Error: {e}")
#         return None, str(e)

def get_random_free_ipv4_address():
    net = ipaddress.ip_network("172.19.1.0/24")
    lst1 = [str(i) for i in net.hosts()][1:]
    # 获取所有容器ID
    containers = client.containers.list(all=True)
    # 获取容器的IP地址
    ip_address_list = []
    for container in containers:
        # 获取容器的网络信息
        networks = container.attrs.get('NetworkSettings', {}).get('Networks', {})
        for _, network_info in networks.items():
            ip_address = network_info.get('IPAddress')
            ip_address_list.append(ip_address)
    lst2 = list(set(lst1) - set(ip_address_list))
    return lst2[0]

def get_random_free_port():
    while True:
        port = random.randint(1024, 65535)
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        result = sock.connect_ex((remote_ip, port))
        sock.close()
        if result != 0:  # 端口未被占用
            return port

def getpages(cur_page, counts):
    page_list = ['1']
    max_page = math.ceil(counts / per_page)
    if max_page <= 5:
        page_list = [str(i) for i in range(1, max_page + 1)]
    else:
        cur_list = [str(i) for i in range(cur_page - 2, cur_page + 3) if i in range(2, max_page)]
        if (int(cur_list[0]) > 2):
            page_list.extend(['...'])
        page_list.extend(cur_list)
        if (int(cur_list[-1]) <= max_page - 2):
            page_list.extend(['...'])
        page_list.extend([str(max_page)])
    if cur_page > 1:
        page_list.insert(0, '<')
    if cur_page < max_page:
        page_list.append('>')
    return page_list

def get_images():
    images = client.images.list()
    image_list = []
    for image in images:
        dics = json.loads(json.dumps(image.attrs))
        if dics['RepoTags'][0].startswith('postgresql:'):
            image_list.append(dics['RepoTags'][0])
    return image_list

def get_image_list(page):
    images = client.images.list()
    image_list = []
    for image in images:
        dics = json.loads(json.dumps(image.attrs))
        dics["Id"] = dics["Id"][7:]
        dics["RepoTags"] = dics["RepoTags"][0]
        dt = parser.isoparse(dics["Created"])
        # 格式化日期为所需的格式
        dics["Created"] = dt.strftime('%Y-%m-%d %H:%M:%S')
        image_list.append(dics)
    page_list = getpages(int(page), len(image_list))
    data = {
        "content_list": image_list[10 * (int(page) - 1):10 * int(page)],
        "page_list": page_list,
        "cur_page": str(page),
        "content_total": str(len(image_list)),
        "view_name": "myview.imageList",
    }
    return data

def get_container_list(page):
    # 获取所有容器的信息，包含正在运行和已停止的容器
    containers = client.containers.list(all=True)
    container_list = []
    for container in containers:
        dics = json.loads(json.dumps(container.attrs))
        # 提取 HostIp 和 HostPort 并转换格式
        formatted_mapping = []
        for container_port, host_ports in dics["NetworkSettings"]["Ports"].items():
            for port in host_ports:
                host_ip = port["HostIp"]
                host_port = port["HostPort"]
                formatted_mapping.append(f"{host_ip}:{host_port}->{container_port}")
        dics["Ports"] = formatted_mapping[0]
        dt = parser.isoparse(dics["Created"])
        # 格式化日期为所需的格式
        dics["Created"] = dt.strftime('%Y-%m-%d %H:%M:%S')
        container_list.append(dics)
    page_list = getpages(int(page), len(container_list))
    data = {
        "content_list": container_list[10 * (int(page) - 1):10 * int(page)],
        "page_list": page_list,
        "cur_page": str(page),
        "content_total": str(len(container_list)),
        "view_name": "myview.containerManager",
    }
    return data
