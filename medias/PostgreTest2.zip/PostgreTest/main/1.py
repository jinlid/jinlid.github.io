import docker, json

client = docker.DockerClient(base_url="tcp://192.168.137.129:2375")

# 列出所有镜像
# images = client.images.list()
# for image in images:
#     dics = json.loads(json.dumps(image.attrs))
#     print(dics['RepoTags'][0])
# image_json = [json.dumps(image.attrs) for image in images]
# for img in image_json:
#     print(img)

# 通过镜像 ID 或镜像名称来移除镜像
def remove_image(image_name_or_id):
    try:
        # 移除镜像
        client.images.remove(image_name_or_id)
        print(f"Image '{image_name_or_id}' removed successfully.")
    except docker.errors.ImageNotFound:
        print(f"Image '{image_name_or_id}' not found.")
    except docker.errors.APIError as e:
        print(f"Error removing image '{image_name_or_id}': {e}")

# 通过镜像 ID 或镜像名称来强制移除镜像
def force_remove_image(image_name_or_id):
    try:
        # 强制移除镜像
        client.images.remove(image_name_or_id, force=True)
        print(f"Image '{image_name_or_id}' forced removed successfully.")
    except docker.errors.ImageNotFound:
        print(f"Image '{image_name_or_id}' not found.")
    except docker.errors.APIError as e:
        print(f"Error removing image '{image_name_or_id}': {e}")

# 删除所有未使用的镜像（即悬空镜像）
def prune_unused_images():
    try:
        client.images.prune()
        print("Unused images pruned successfully.")
    except docker.errors.APIError as e:
        print(f"Error pruning unused images: {e}")

# [<Image: 'postgresql:15.10'>, <Image: 'postgresql:16.6'>, <Image: 'postgresqlenv:latest'>, <Image: 'hub.oepkgs.net/openeuler/openeuler:latest'>]


# 创建并启动容器：
# container = client.containers.run('alpine', 'echo hello world', detach=True)
# print(container.logs())  # 获取容器的日志输出


# 列出所有容器
# containers = client.containers.list()
# for container in containers:
#     print(container)


# # 获取所有容器（包括停止的容器）
# def get_all_containers():
#     try:
#         # 获取所有容器的信息，包含正在运行和已停止的容器
#         containers = client.containers.list(all=True)
#
#         # 将每个容器信息格式化为 JSON
#         containers_json = [json.dumps(container.attrs) for container in containers]
#
#         # 输出容器的 JSON 信息
#         for container_info in containers_json:
#             print(container_info)
#
#     except docker.errors.APIError as e:
#         print(f"Error retrieving container list: {e}")
#
# # 调用函数获取所有容器
# get_all_containers()

# 查看容器的详细信息
# container = client.containers.get('postgresql_16.61')  # 获取指定容器
# print(container.attrs)  # 获取容器的详细信息


# 停止容器
# container.stop()

# 删除容器
# container.remove()

# 列出所有网络
# networks = client.networks.list()
# for network in networks:
#     print(network.name)

# 获取所有容器 ID
containers = client.containers.list(all=True)
# 获取每个容器的 IP 地址
ip_address_list = []
for container in containers:
    # 获取容器的网络信息
    networks = container.attrs.get('NetworkSettings', {}).get('Networks', {})
    # 遍历所有网络，打印每个容器的 IP 地址
    for network_name, network_info in networks.items():
        ip_address = network_info.get('IPAddress')
        ip_address_list.append(ip_address)

print(ip_address_list)

# 创建网络
# network = client.networks.create('my_network', driver='bridge')

# 查看日志
# container = client.containers.get('container_id_or_name')
# print(container.logs())
# 执行命令
# exec_log = container.exec_run('ls /')
# print(exec_log.output)

