import docker
from docker.errors import NotFound

# 初始化 Docker 客户端
client = docker.DockerClient(base_url="tcp://192.168.137.129:2375")

# 定义网络名称
network_name = "postgrenetwork"

# 尝试获取网络
try:
    # 查找指定名称的网络
    network = client.networks.get(network_name)
    print(f"Network '{network_name}' already exists.")
except NotFound:
    # 如果网络不存在，则创建该网络
    print(f"Network '{network_name}' does not exist. Creating...")
    network = client.networks.create(
        network_name,
        driver="bridge",
        ipam=docker.types.IPAMConfig(
            pool_configs=[docker.types.IPAMPool(subnet="172.19.1.0/24")]
        )
    )
    print(f"Network '{network_name}' created successfully.")
