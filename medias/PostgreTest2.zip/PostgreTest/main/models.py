from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import func
db = SQLAlchemy()

class Task(db.Model):
    __tablename__ = 'tasks'

    task_id = db.Column(db.BigInteger, primary_key=True)
    repository = db.Column(db.String(100), nullable=False)
    status = db.Column(db.String(50), nullable=True)
    detail_info = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=func.now())
    updated_at = db.Column(db.DateTime, default=func.now(), onupdate=func.now())

    def __repr__(self):
        return f'<Task {self.task_id}>'

    def to_dict(self):
        return {
            'task_id': self.task_id,
            'repository': self.repository,
            'status': self.status,
            'detail_info': self.detail_info,
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M:%S') if self.created_at else None,
            'updated_at': self.updated_at.strftime('%Y-%m-%d %H:%M:%S') if self.updated_at else None,
        }

def create_all_tables(app):
    with app.app_context():
        db.create_all()