import docker, os

BASE_DIR = os.path.abspath(os.path.dirname(__file__))

client = docker.DockerClient(base_url="tcp://192.168.137.129:2375")

build_args = {
    'URL': 'https://mirrors.aliyun.com/postgresql/source',
    'PGVERSION': '15.10'
}

logs=[]
try:
    image, logs = client.images.build(
        path=BASE_DIR + '/scripts',
        tag='postgresql:15.10',
        buildargs=build_args,
        rm=True,
    )
    print(logs)
except docker.errors.DockerException as e:
    print('Error building image:', e)
finally:
    # 遍历日志输出
    for line in logs:
        if 'stream' in line:
            stream = line['stream'].strip()  # 去掉可能的前后空格
            if stream:  # 只有非空内容才打印
                print(stream)
        elif 'error' in line:
            print(f"Error: {line['error']}")  # 如果有错误，打印错误信息


