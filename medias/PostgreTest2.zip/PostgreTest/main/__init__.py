import os
from flask import Flask
from flask_socketio import SocketIO

socketio = SocketIO(cors_allowed_origins="*", async_mode="eventlet")

def create_app():
    app = Flask(__name__,
                template_folder=os.path.join(os.path.dirname(__file__), 'templates'),
                static_folder=os.path.join(os.path.dirname(__file__), 'static'))
    # 配置数据库
    app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:123456@192.168.137.129:5432/mydb2'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False  # 禁用对象修改追踪
    # app.config['SQLALCHEMY_COMMIT_ON_TEARDOWN'] = True  # 自动提交事务

    from PostgreTest.main.models import db, create_all_tables
    # 初始化数据库
    db.init_app(app)
    create_all_tables(app)

    from PostgreTest.main.routes import myview
    app.register_blueprint(myview)

    # 将 SocketIO 和 app 绑定
    socketio.init_app(app)
    return app