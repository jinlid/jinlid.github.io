from PostgreTest.main import create_app, socketio

app = create_app()
if __name__ == '__main__':
    socketio.run(app, host="192.168.0.105", port=9096, debug=True)