import time, json, asyncio
import concurrent.futures
from datetime import datetime, timezone
from typing import Optional, List, Dict, Any
from kubernetes import stream
from kubernetes.client.models import v1_stateful_set, v1_stateful_set_spec, V1StatefulSet, V1Pod

from kubernetes.client import ApiException
from fastapi import WebSocket
from fastapi.websockets import WebSocketState
from FastPodTest import *


def create_statefulset(
        task_id: str,
        image_name: str,
        version: str,
        websocket: WebSocket,
        namespace: str = 'default',
        expected_replicas: int = 2,
        image_pull_secret: str = 'harbor-secret',
        pvc_claim_name: str = 'myclaim01',
) -> Dict[str, Any]:
    """创建StatefulSet并通过WebSocket实时推送日志"""
    # 辅助函数：通过WebSocket发送日志（同步函数中调用异步方法）
    global api_client

    def send_log(log_type: str, content: str):
        # 在同步函数中通过事件循环调用异步的send_text
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            # 检查WebSocket连接状态
            if websocket.client_state == WebSocketState.CONNECTED:
                loop.run_until_complete(websocket.send_text(json.dumps({
                    "Primary": log_type,  # Primary/Standby/info/error
                    "content": content
                })))
        except Exception as e:
            logger.warning(f"日志发送失败: {str(e)}")
        finally:
            loop.close()

    try:
        # 获取全新的客户端
        core_api, batch_api, apps_api, api_client = get_k8s_clients()

        # 1. 初始化Pod名称
        pod_name_base = '-'.join(version.lower().split()) + '-' + task_id + '-dup'
        send_log("Primary", f"开始创建StatefulSet: {pod_name_base}")

        # 2. 构建StatefulSet对象（保持原逻辑）
        body = v1_stateful_set.V1StatefulSet(
            api_version="apps/v1",
            kind="StatefulSet",
            metadata=client.V1ObjectMeta(
                name=pod_name_base,
                labels={"app": pod_name_base}
            ),
            spec=v1_stateful_set_spec.V1StatefulSetSpec(
                service_name=f"{pod_name_base}-service",  # 补充必填的serviceName
                replicas=expected_replicas,
                selector=client.V1LabelSelector(
                    match_labels={"app": pod_name_base}
                ),
                template=client.V1PodTemplateSpec(
                    metadata=client.V1ObjectMeta(
                        labels={"app": pod_name_base}
                    ),
                    spec=client.V1PodSpec(
                        containers=[
                            client.V1Container(
                                name=pod_name_base,
                                image=image_name,
                                ports=[client.V1ContainerPort(container_port=5432)],
                                volume_mounts=[
                                    client.V1VolumeMount(
                                        name=pvc_claim_name,
                                        mount_path="/data"
                                    )
                                ],
                                command=["sleep", "infinity"]  # 保持容器活跃
                            )
                        ],
                        volumes=[
                            client.V1Volume(
                                name=pvc_claim_name,
                                persistent_volume_claim=client.V1PersistentVolumeClaimVolumeSource(
                                    claim_name=pvc_claim_name
                                )
                            )
                        ],
                        image_pull_secrets=[
                            client.V1LocalObjectReference(name=image_pull_secret)
                        ],
                        node_selector={
                            "node-type": "worker"
                        }
                    )
                ),
            )
        )

        # 3. 创建StatefulSet
        send_log("Primary", f"正在创建StatefulSet: {pod_name_base}")
        apps_api.create_namespaced_stateful_set(namespace=namespace, body=body)

        # 4. 等待Pod就绪
        send_log("Primary", f"等待Pod就绪: {pod_name_base}")
        ip_data = wait_for_pods_ready(
            core_api=core_api,
            namespace=namespace,
            base_pod_name=pod_name_base,
            expected_replicas=expected_replicas
        )

        if not ip_data or len(ip_data) < 2:
            raise RuntimeError(f'至少需要两个就绪的pod，当前就绪: {len(ip_data)}')
        send_log("Primary", f"所有Pod就绪，IP映射: {ip_data}")

        # -------------------------- 阶段1：并行执行安装脚本 --------------------------
        send_log("Primary", "开始并行执行安装脚本")
        install_futures = []
        with concurrent.futures.ThreadPoolExecutor(max_workers=expected_replicas) as executor:
            for i in range(expected_replicas):
                pod_name = f"{pod_name_base}-{i}"
                script_name = install_script_map.get('openGauss')
                # 构建安装命令
                exec_command = [
                    '/bin/sh',
                    f'{script_base_path}/{script_name}',
                    ip_data[0] if i == 0 else ip_data[1],
                    ip_data[1] if i == 0 else ip_data[0]
                ]

                send_log("Primary" if i == 0 else "Standby",
                         f"在Pod {pod_name} 中执行安装命令: {' '.join(exec_command)}")
                # 传递websocket给执行函数，用于推送该Pod的日志
                future = executor.submit(
                    exec_command_in_pod_stream,
                    core_api=core_api,  # 传递当前的core_api实例
                    namespace=namespace,
                    pod_name=pod_name,
                    exec_command=exec_command,
                    container=pod_name_base,
                    websocket=websocket,  # 传递WebSocket对象
                    log_type="Primary" if i == 0 else "Standby"  # 区分日志类型
                )
                install_futures.append(future)

        # 等待安装完成
        for future in concurrent.futures.as_completed(install_futures):
            try:
                future.result()
            except Exception as e:
                send_log("Primary", f"安装脚本执行失败: {str(e)}")
                raise RuntimeError("部分Pod安装脚本执行失败")

        # -------------------------- 阶段2：串行执行启动脚本 --------------------------
        # 执行pod0（主节点）
        pod0_name = f"{pod_name_base}-0"
        pod0_command = ['/bin/sh', f'{script_base_path}/start_db.sh', 'Primary']
        send_log("Primary", f"开始执行pod0 {pod0_name} 的启动脚本")
        exec_command_in_pod_stream(
            core_api=core_api,  # 传递当前的core_api实例
            namespace=namespace,
            pod_name=pod0_name,
            exec_command=pod0_command,
            container=pod_name_base,
            websocket=websocket,
            log_type="Primary"
        )
        send_log("Primary", f"pod0 {pod0_name} 启动脚本执行完成")

        # 执行pod1（备节点）
        pod1_name = f"{pod_name_base}-1"
        pod1_command = ['/bin/sh', f'{script_base_path}/start_db.sh', 'Standby']
        send_log("Standby", f"开始执行pod1 {pod1_name} 的启动脚本")
        exec_command_in_pod_stream(
            core_api=core_api,  # 传递当前的core_api实例
            namespace=namespace,
            pod_name=pod1_name,
            exec_command=pod1_command,
            container=pod_name_base,
            websocket=websocket,
            log_type="Standby"
        )
        send_log("Standby", f"pod1 {pod1_name} 启动脚本执行完成")

        return {'pod_ips': ip_data}

    except Exception as e:
        send_log("Primary", f"流程执行失败: {str(e)}")
        raise
    finally:
        # 操作完成后关闭客户端
        close_k8s_clients(api_client)


def exec_command_in_pod_stream(
        core_api: client.CoreV1Api,  # 新增：接收core_api客户端实例
        namespace: str,
        pod_name: str,
        exec_command: list,
        container: str,
        websocket: WebSocket,  # 接收WebSocket对象
        log_type: str  # 日志类型：Primary/Standby
) -> None:
    """在Pod中执行命令，并通过WebSocket推送实时日志"""
    try:
        # 调用K8s API执行命令
        response = stream.stream(
            core_api.connect_get_namespaced_pod_exec,
            name=pod_name,
            namespace=namespace,
            container=container,
            command=exec_command,
            stderr=True,
            stdin=False,
            stdout=True,
            tty=False,
            _preload_content=False
        )

        # 实时读取输出并通过WebSocket发送
        while response.is_open():
            response.update(timeout=1)
            # 读取标准输出
            if response.peek_stdout():
                stdout = response.read_stdout()
                # 通过WebSocket发送（同步函数中调用异步方法）
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                loop.run_until_complete(websocket.send_text(json.dumps({
                    "type": log_type,
                    "content": stdout.strip()
                })))
                loop.close()
            # 读取标准错误
            if response.peek_stderr():
                stderr = response.read_stderr()
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                loop.run_until_complete(websocket.send_text(json.dumps({
                    "type": "Primary",
                    "content": f"[{pod_name}错误] {stderr.strip()}"
                })))
                loop.close()

        # 检查命令执行结果
        if response.returncode != 0:
            raise RuntimeError(f"{pod_name} 命令执行失败，退出码: {response.returncode}")

    except Exception as e:
        # 错误信息通过WebSocket发送
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        loop.run_until_complete(websocket.send_text(json.dumps({
            "type": "Primary",
            "content": f"[{pod_name}执行异常] {str(e)}"
        })))
        loop.close()
        raise


def get_statefulset_list(
        namespace: Optional[str] = None,
) -> List[Dict[str, str]]:
    """
    获取StatefulSet列表信息（适配get_k8s_clients()客户端管理模式）

    :param namespace: 可选，指定命名空间
    :param use_existing_clients: 可选，已有的客户端元组 (core_api, batch_api, apps_api, api_client)
    :return: 包含statefulsets列表的字典
    """
    statefulsets: List[Dict[str, str]] = []

    core_api, batch_api, apps_api, api_client = get_k8s_clients()

    try:
        # 根据命名空间筛选
        if namespace:
            response = apps_api.list_namespaced_stateful_set(
                namespace=namespace, watch=False
            )
        else:
            response = apps_api.list_stateful_set_for_all_namespaces(
                watch=False
            )

        for sts in response.items:
            sts: V1StatefulSet  # 类型提示

            # 计算AGE（使用UTC时区避免时差问题）
            creation_time = sts.metadata.creation_timestamp.replace(tzinfo=timezone.utc)
            current_time = datetime.now(timezone.utc)
            age_minutes = int((current_time - creation_time).total_seconds() // 60)

            # 提取容器信息
            containers = sts.spec.template.spec.containers
            container_names = [c.name for c in containers]
            container_images = [c.image for c in containers]

            sts_info = {
                "NAME": sts.metadata.name,
                "READY": (
                    f"{sts.status.ready_replicas}/{sts.status.replicas}"
                    if sts.status.replicas and sts.status.ready_replicas
                    else f"0/{sts.status.replicas or 0}"
                ),
                "AGE": f"{age_minutes}m",
                "CONTAINERS": ",".join(container_names) if container_names else "N/A",
                "IMAGES": ",".join(container_images) if container_images else "N/A",
                "NAMESPACE": sts.metadata.namespace
            }
            statefulsets.append(sts_info)

        return statefulsets

    except ApiException as e:
        error_msg = f"获取StatefulSet失败 (命名空间: {namespace or 'all'}): {e.reason} (代码: {e.status})"
        raise RuntimeError(error_msg) from e
    except Exception as e:
        raise RuntimeError(f"处理StatefulSet数据时出错: {str(e)}") from e
    finally:
        close_k8s_clients(api_client)


def get_pod_list(
        namespace: Optional[str] = None,
        statefulset_name: Optional[str] = None,
) -> List[Dict[str, str]]:
    """
    获取Pod列表信息（适配get_k8s_clients()客户端管理模式）

    :param namespace: 可选，指定命名空间
    :param statefulset_name: 可选，过滤特定StatefulSet的Pod
    :return: 包含pods列表的字典
    """
    pods: List[Dict[str, str]] = []

    # 获取客户端实例
    core_api, batch_api, apps_api, api_client = get_k8s_clients()

    try:
        # 获取Pod列表
        if namespace:
            response = core_api.list_namespaced_pod(
                namespace=namespace, watch=False
            )
        else:
            response = core_api.list_pod_for_all_namespaces(
                watch=False
            )

        for pod in response.items:
            pod: V1Pod  # 类型提示

            # 过滤特定StatefulSet的Pod
            if statefulset_name:
                is_owned_by_sts = any(
                    ref.kind == "StatefulSet" and ref.name == statefulset_name
                    for ref in pod.metadata.owner_references
                )
                if not is_owned_by_sts:
                    continue

            # 计算就绪状态和重启次数
            container_statuses = pod.status.container_statuses or []
            ready_count = sum(1 for c in container_statuses if c.ready)
            total_count = len(container_statuses)
            restart_count = sum(c.restart_count for c in container_statuses)

            # 计算AGE
            creation_time = pod.metadata.creation_timestamp.replace(tzinfo=timezone.utc)
            current_time = datetime.now(timezone.utc)
            age_minutes = int((current_time - creation_time).total_seconds() // 60)

            # 就绪门控处理
            readiness_gates = pod.spec.readiness_gates or []
            readiness_gate_str = (
                readiness_gates[0].condition_type
                if readiness_gates else "<none>"
            )

            pod_info = {
                "NAME": pod.metadata.name,
                "READY": f"{ready_count}/{total_count}",
                "STATUS": pod.status.phase or "Unknown",
                "RESTARTS": f"{restart_count}",
                "AGE": f"{age_minutes}m",
                "IP": pod.status.pod_ip or "N/A",
                "NODE": pod.spec.node_name or "N/A",
                "NOMINATED NODE": pod.status.nominated_node_name or "<none>",
                "READINESS GATES": readiness_gate_str,
                "NAMESPACE": pod.metadata.namespace,
                "STATEFULSET": next(
                    (ref.name for ref in pod.metadata.owner_references if ref.kind == "StatefulSet"),
                    "N/A"
                )
            }
            pods.append(pod_info)

        return pods

    except ApiException as e:
        error_msg = f"获取Pod失败 (命名空间: {namespace or 'all'}): {e.reason} (代码: {e.status})"
        raise RuntimeError(error_msg) from e
    except Exception as e:
        raise RuntimeError(f"处理Pod数据时出错: {str(e)}") from e
    finally:
        close_k8s_clients(api_client)


def delete_statefulset_if_exists(
        statefulset_name: str,
        namespace: str = 'default',
        grace_period: int = 0,
        propagation_policy: str = 'Background',
) -> bool:
    """删除StatefulSet（如果存在）"""
    # 获取客户端实例
    core_api, batch_api, apps_api, api_client = get_k8s_clients()
    try:
        # 检查StatefulSet是否存在
        apps_api.read_namespaced_stateful_set(
            name=statefulset_name,
            namespace=namespace
        )
    except ApiException as e:
        if e.status == 404:
            logger.info(f"StatefulSet '{statefulset_name}' 不存在，无需删除")
            return False
        else:
            logger.error(f"检查StatefulSet是否存在时出错: {str(e)}")
            raise

    try:
        body = client.V1DeleteOptions(
            propagation_policy=propagation_policy,
            grace_period_seconds=grace_period
        )
        apps_api.delete_namespaced_stateful_set(
            name=statefulset_name,
            namespace=namespace,
            body=body
        )
        logger.info(f"成功删除StatefulSet: {statefulset_name}")
        return True
    except ApiException as e:
        logger.error(f"删除StatefulSet失败: {str(e)}")
        raise
    finally:
        close_k8s_clients(api_client)

def wait_for_pods_ready(
        core_api: client.CoreV1Api,
        namespace: str,
        base_pod_name: str,
        expected_replicas: int,
        timeout: int = 300) -> \
        Dict[int, str]:
    """等待StatefulSet的所有Pod就绪并返回其IP地址"""
    # 实现等待Pod就绪的逻辑
    start_time = time.time()
    pod_ips = {}

    while len(pod_ips) < expected_replicas and (time.time() - start_time) < timeout:
        try:
            pods = core_api.list_namespaced_pod(
                namespace=namespace,
                label_selector=f"app={base_pod_name}"
            )

            for pod in pods.items:
                # 提取Pod序号（StatefulSet的Pod名称格式为{base}-0, {base}-1等）
                try:
                    pod_index = int(pod.metadata.name.split('-')[-1])
                except (IndexError, ValueError):
                    continue

                # 检查Pod是否就绪
                # 检查Pod是否就绪
                if pod.status.phase == "Running" and all(
                        cond.status == "True" for cond in pod.status.conditions
                        if cond.type == "Ready"
                ):
                    if pod_index not in pod_ips:
                        pod_ips[pod_index] = pod.status.pod_ip
                        logger.info(f"Pod {pod.metadata.name} 已就绪，IP: {pod.status.pod_ip}")

        except ApiException as e:
            logger.error(f"获取Pod状态时出错: {str(e)}")

        time.sleep(1)  # 等待5秒后重试

    if len(pod_ips) < expected_replicas:
        logger.warning(f"超时: 仅 {len(pod_ips)}/{expected_replicas} 个Pod就绪")

    return pod_ips
