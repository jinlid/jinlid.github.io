from fastapi import APIRouter, Request
from fastapi.templating import Jinja2Templates
from FastPodTest import logger
from FastPodTest.utils.tools import getpages
from FastPodTest.utils.statefulsetManager import get_statefulset_list, get_pod_list

router = APIRouter()
# 指定HTML模板存放目录（假设在项目根目录的templates文件夹）
templates = Jinja2Templates(directory="templates")


@router.get("/")
async def read_index(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})


@router.get("/statefulsetList/{page}")
async def statefulsetList(request: Request, page: int = 1):
    statefulsets = get_statefulset_list(namespace='default')
    logger.info(f"获取到的StatefulSet列表: {statefulsets}")
    page_list = getpages(int(page), len(statefulsets))
    content_list = statefulsets[10 * (int(page) - 1):10 * int(page)]
    # 返回模板响应
    return templates.TemplateResponse(
        "statefulsetList.html",
        {
            "request": request,  # 必须传递request对象
            "content_list": content_list,
            "page_list": page_list,
            "cur_page": str(page),
            "content_total": str(len(statefulsets)),
            "view_name": "statefulsetList",
        }
    )


@router.get("/podList/{page}")
async def podList(request: Request, page: int = 1):
    pods = get_pod_list(namespace='default')
    logger.info(f"获取到的StatefulSet列表: {pods}")
    page_list = getpages(int(page), len(pods))
    content_list = pods[10 * (int(page) - 1):10 * int(page)]
    # 返回模板响应
    return templates.TemplateResponse(
        "podList.html",
        {
            "request": request,  # 必须传递request对象
            "content_list": content_list,
            "page_list": page_list,
            "cur_page": str(page),
            "content_total": str(len(pods)),
            "view_name": "podList",
        }
    )

@router.get("/{template}")
async def read_template(request: Request, template: str):
    return templates.TemplateResponse(f"{template}.html", {"request": request})
