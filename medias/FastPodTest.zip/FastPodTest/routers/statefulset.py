# routers/statefulset.py
import json, asyncio
import concurrent.futures
from pydantic import BaseModel
from fastapi import APIRouter, WebSocket, Request, WebSocketDisconnect
from fastapi.responses import JSONResponse
from fastapi.websockets import WebSocketState
from FastPodTest import logger
from FastPodTest.utils.statefulsetManager import create_statefulset, delete_statefulset_if_exists

router = APIRouter()

@router.websocket("/addStateFulset")
async def addStateFulset(websocket: WebSocket):
    await websocket.accept()  # 建立WebSocket连接
    logger.info("客户端WebSocket连接已建立")
    try:
        data = await websocket.receive_json()  # 接收文本消息
        logger.info(f"收到WebSocket消息: {data}")

        # 向客户端确认收到消息
        await websocket.send_text(json.dumps({
            "type": "info",
            "content": f"服务器已收到任务: {data['task_id']}"
        }))
        # 调用create_statefulset函数（关键：传递websocket对象，处理同步函数异步调用）
        # 使用线程池执行同步函数，避免阻塞WebSocket事件循环
        loop = asyncio.get_event_loop()
        with concurrent.futures.ThreadPoolExecutor() as pool:
            result = await loop.run_in_executor(
                pool,
                create_statefulset,
                data["task_id"],
                data["image_name"],
                data["version"],
                websocket,
                'default',
                2,
                'harbor-secret',
                'myclaim01'
            )

        # 5. 任务完成后通知客户端
        await websocket.send_text(json.dumps({
            "type": "complete",
            "content": f"任务执行完成，Pod IP: {result['pod_ips']}"
        }))

    except WebSocketDisconnect:
        logger.info("客户端主动断开WebSocket连接")
    except Exception as e:
        logger.error(f"WebSocket处理异常: {str(e)}", exc_info=True)
        # 发生错误时通过WebSocket通知客户端
        if websocket.client_state == WebSocketState.CONNECTED:
            await websocket.send_text(json.dumps({
                "type": "error",
                "content": f"服务器错误: {str(e)}"
            }))
    finally:
        # 确保连接关闭
        if websocket.client_state == WebSocketState.CONNECTED:
            await websocket.close()

# 定义请求体模型
class DeleteStatefulset(BaseModel):
    statefulset_name: str  # 与前端传递的字段名一致

@router.post("/deleteStatefulset", response_class=JSONResponse)
async def deleteStatefulset(request: DeleteStatefulset):
    """处理删除StatefulSet的请求"""
    statefulset_name = request.statefulset_name  # 提取参数
    try:
        # 执行删除操作
        deleted = delete_statefulset_if_exists(statefulset_name)
        if deleted:
            return {"status": "success", "message": f"StatefulSet {statefulset_name} 已开始删除"}
        else:
            return {"status": "warning", "message": f"StatefulSet {statefulset_name} 不存在"}
    except Exception as e:
        # 捕获所有异常并返回友好提示
        return {
            "status": "error",
            "error": str(e)
        }