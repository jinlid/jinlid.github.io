# main.py
import uvicorn
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from FastPodTest.routers import pages, statefulset

app = FastAPI()
app.mount("/static", StaticFiles(directory="static"), name="static")


app.include_router(pages.router)
app.include_router(statefulset.router, prefix='/statefulset')


if __name__ == "__main__":
    uvicorn.run(app=app, host="127.0.0.1", port=8000)