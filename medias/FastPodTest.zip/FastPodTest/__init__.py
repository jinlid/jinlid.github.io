# __init__.py
import logging
import os
from kubernetes import client

logger = logging.getLogger(__name__)
logging.basicConfig(format='%(asctime)s %(message)s', level=logging.INFO)

script_base_path = '/data/scripts'
install_script_map = {
    'openGauss': 'install_openGauss.sh'
}
k8s_url = 'https://192.168.137.226:6443'


def _init_external_api_config() -> client.Configuration:
    """创建全新的Kubernetes配置对象（每次调用都返回新实例）"""
    config = client.Configuration()
    config.host = k8s_url
    config.verify_ssl = True # # 若证书有问题，可临时设为False调试（生产环境不建议）
    config.ssl_ca_cert = 'resource/ca.crt'

    # # 认证方式：优先使用证书，否则使用Token
    cert_file = 'resource/apiserver-kubelet-client.crt'
    key_file = 'resource/apiserver-kubelet-client.key'
    if os.path.exists(cert_file) and os.path.exists(key_file):
        config.cert_file = cert_file
        config.key_file = key_file
        logger.debug('使用客户端证书进行认证')
    else:
        # 读取Token（每次调用都重新读取，避免Token过期）
        token = get_token()
        config.api_key = {"authorization": "Bearer " + get_token()}  # 添加空格
        logger.debug('使用Token进行认证')
    return config


def get_token() -> str:
    """读取Token（每次调用都重新读取，确保最新）"""
    token_file = 'resource/token.txt'
    if not os.path.exists(token_file):
        raise FileNotFoundError(f'认证token文件未找到：{token_file}')
    with open(token_file, 'r') as f:
        token = f.read().strip()
        if not token:
            raise ValueError('读取的Token文件内容为空')
    return token

def get_k8s_clients() -> tuple:
    """动态创建Kubernetes客户端实例（每次调用返回全新实例）"""
    config = _init_external_api_config()
    api_client = client.ApiClient(config)  # 全新的ApiClient
    # 返回全新的客户端实例
    return (
        client.CoreV1Api(api_client),
        client.BatchV1Api(api_client),
        client.AppsV1Api(api_client),
        api_client  # 返回ApiClient，便于后续关闭
    )

def close_k8s_clients(api_client: client.ApiClient) -> None:
    """关闭Kubernetes客户端，释放资源"""
    try:
        api_client.close()
        logger.debug('Kubernetes客户端资源已释放')
    except Exception as e:
        logger.warning(f'关闭客户端时发生错误：{str(e)}')

