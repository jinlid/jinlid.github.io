from gitPGCommit.main import create_app, socketio

app = create_app()
if __name__ == '__main__':
    socketio.run(app, host="192.168.137.129", port=9097, debug=True)