from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import func
db = SQLAlchemy()

class Task(db.Model):
    __tablename__ = 'task'

    task_id = db.Column(db.BigInteger, primary_key=True)
    organization = db.Column(db.String(100), nullable=False)
    repository = db.Column(db.String(100), nullable=False)
    branch = db.Column(db.String(100), nullable=False)
    status = db.Column(db.String(50), nullable=True)
    start_at = db.Column(db.DateTime)
    end_at = db.Column(db.DateTime)
    detail_info = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=func.now())
    updated_at = db.Column(db.DateTime, default=func.now(), onupdate=func.now())

    def __repr__(self):
        return f'<Task {self.task_id}>'

    def to_dict(self):
        return {
            'task_id': self.task_id,
            'organization': self.organization,
            'repository': self.repository,
            'branch': self.branch,
            'status': self.status,
            'start_at': self.start_at.strftime('%Y-%m-%d %H:%M:%S') if self.start_at else None,
            'end_at': self.end_at.strftime('%Y-%m-%d %H:%M:%S') if self.end_at else None,
            'detail_info': self.detail_info,
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M:%S') if self.created_at else None,
            'updated_at': self.updated_at.strftime('%Y-%m-%d %H:%M:%S') if self.updated_at else None,
        }

class ComRecord(db.Model):
    __tablename__ = 'commit_record'
    commit_sha = db.Column(db.String(100), primary_key=True)
    commit_message = db.Column(db.Text, nullable=True)
    commit_author = db.Column(db.String(100), nullable=True)
    commit_date = db.Column(db.DateTime, nullable=True)
    organization = db.Column(db.String(100), nullable=False)
    repository = db.Column(db.String(100), nullable=False)
    branch = db.Column(db.String(100), nullable=False)
    commit_html_url = db.Column(db.String(100), nullable=True)
    created_at = db.Column(db.DateTime, default=func.now())
    updated_at = db.Column(db.DateTime, default=func.now(), onupdate=func.now())

    def __repr__(self):
        return f'<ComRecord {self.commit_sha}>'

    def to_dict(self):
        return {
            'commit_sha': self.commit_sha,
            'commit_message': self.commit_message,
            'commit_author': self.commit_author,
            'commit_date': self.commit_date,
            'organization': self.organization,
            'repository': self.repository,
            'branch': self.branch,
            'commit_html_url': self.commit_html_url,
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M:%S') if self.created_at else None,
            'updated_at': self.updated_at.strftime('%Y-%m-%d %H:%M:%S') if self.updated_at else None,
        }


def create_all_tables(app):
    with app.app_context():
        db.create_all()