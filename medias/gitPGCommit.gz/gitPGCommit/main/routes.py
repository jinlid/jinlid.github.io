import logging, os, requests, traceback
from flask import request, render_template, jsonify
from flask import Blueprint
from datetime import datetime
from gitPGCommit.main import socketio
from gitPGCommit.main.utils import *
from gitPGCommit.main.ext import TaskService, ComRecordService
from flask import current_app
logger = logging.getLogger(__name__)
logging.basicConfig(format='%(asctime)s %(message)s', level=logging.INFO)
myview = Blueprint("myview", __name__)
BASE_DIR = os.path.abspath(os.path.dirname(__file__))

# 主页
@myview.route("/")
def index():
    return render_template("index.html")

@myview.route("/<name>", methods=['GET'])
def render(name):
    return render_template(name + ".html")

@myview.route('/taskManager', methods=['GET'])
def taskManager():
    # 使用 request.args.get() 来获取 URL 中的查询参数
    page = int(request.args.get('page', 1))  # 默认第一页
    data = TaskService.get_tasks(page)
    logger.debug(data)
    return render_template("taskManager.html", **data)

def long_running_task(data, app, socketio):
    task_id = data['task_id']
    status = 'Running'
    detail_info = None
    with app.app_context():
        TaskService.update_task_status(task_id=task_id,
                                status=status,
                                updated_at=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                                )
    socketio.emit('task_update',
                  {'task_id': task_id,
                   'status': status,
                   'updated_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                   }
    )
    url = 'https://api.github.com/repos/{organization}/{repository}/commits?sha={branch}&since={start_at}&until={end_at}'.format(
        organization=data['organization'],
        repository=data['repository'],
        branch=data['branch'],
        start_at=data['start_at'],
        end_at=data['end_at'],
    )
    logger.info(url)
    logger.debug(data)
    response = requests.get(url)
    # 检查请求是否成功
    try:
        if response.status_code == 200:
            status = 'Succeeded'
            commits = response.json()  # 获取提交数据
            for commit in commits:
                commit_sha = commit['sha']
                commit_message = commit['commit']['message']
                commit_author = commit['commit']['author']['name']
                commit_date = commit['commit']['author']['date']
                commit_html_url = commit['html_url']
                # 创建任务数据
                create_data = {
                    'commit_sha': commit_sha,
                    'commit_message': commit_message,
                    'commit_author': commit_author,
                    'commit_date': commit_date,
                    'commit_html_url': commit_html_url,
                    'organization': data['organization'],
                    'repository': data['repository'],
                    'branch': data['branch'],
                }
                # 调用任务创建服务
                with app.app_context():
                    ComRecordService.create_commit_record(create_data)
                detail_info = f"检索提交成功，请检查结果"
        else:
            status = 'Failed'
            detail_info = f"无法检索提交，状态码: {response.status_code}"
    except Exception as e:
        status = 'Failed'
        # 捕获异常并记录堆栈信息
        detail_info = f"An error occurred while retrieving commits. Error: {str(e)}\nStack trace: {traceback.format_exc()}"
    finally:
        with app.app_context():
            TaskService.update_task_status(task_id=task_id,
                                           status=status,
                                           detail_info=detail_info,
                                           updated_at = datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                                           )
        socketio.emit('task_update',
                      {'task_id': task_id,
                       'status': status,
                       'detail_info': detail_info,
                       'updated_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                       }
                      )

@socketio.on('page_loaded')
def task_update(data):
    # 处理接收到的数据并启动后台任务
    socketio.start_background_task(long_running_task, data, current_app._get_current_object(), socketio)

@myview.route('/addTask', methods=['GET', 'POST'])
def addTask():
    data = request.get_json()  # 使用 json.loads 解析数据
    logger.debug(data)
    create_data = {
        'task_id': data['task_id'],
        'organization': data['organization'],
        'repository': data['repository'],
        'branch': data['branch'],
        'start_at': data['start_at'],
        'end_at': data['end_at'],
        'status': 'Pending',
    }
    TaskService.create_task(create_data)
    page = int(request.args.get('page', 1))  # 默认第一页
    data = TaskService.get_tasks(page)
    return jsonify(data=data), 202

@myview.route('/commitList', methods=['GET'])
def commitList():
    page = int(request.args.get('page', 1))  # 默认第一页
    data = ComRecordService.get_commmit_list(page)
    logger.debug(data)
    return render_template("commitList.html", **data)







