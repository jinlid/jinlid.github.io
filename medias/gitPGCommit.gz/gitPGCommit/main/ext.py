from sqlalchemy import desc
from gitPGCommit.main.models import db, Task, ComRecord
from gitPGCommit.main.utils import getpages


class TaskService:
    @staticmethod
    def create_task(data):
        new_data = Task(
            task_id=data['task_id'],
            organization=data['organization'],
            repository=data['repository'],
            branch=data['branch'],
            start_at=data['start_at'],
            end_at=data['end_at'],
            status=data['status'],
        )
        db.session.add(new_data)
        db.session.commit()
        return new_data

    @staticmethod
    def update_task_status(task_id, return_code=None, status=None, detail_info=None, updated_at=None):
        task = Task.query.get(task_id)
        if task:
            if return_code is not None:
                task.return_code = return_code
            if status:
                task.status = status
            if detail_info:
                task.detail_info = detail_info
            if updated_at:
                task.updated_at = updated_at
            db.session.commit()
            return task
        return None

    @staticmethod
    def get_tasks(page=1, per_page=10):
        tasks = Task.query.order_by(desc(Task.created_at)).paginate(page=page, per_page=per_page, error_out=False)
        task_list = [task.to_dict() for task in tasks.items]
        data = {
            "content_list": task_list,
            "page_list": getpages(page, per_page, tasks.total),
            "cur_page": str(page),
            "content_total": str(tasks.total),
            "view_name" : "myview.taskManager",
        }
        return data

class ComRecordService:
    @staticmethod
    def create_commit_record(data):
        new_data = ComRecord(
            commit_sha=data['commit_sha'],
            commit_message=data['commit_message'],
            commit_author=data['commit_author'],
            commit_date=data['commit_date'],
            organization=data['organization'],
            repository=data['repository'],
            branch=data['branch'],
            commit_html_url=data['commit_html_url'],
        )
        # 使用 merge 方法进行插入或更新
        db.session.merge(new_data)
        db.session.commit()
        return new_data

    @staticmethod
    def get_commmit_list(page=1, per_page=20):
        comRecords = ComRecord.query.order_by(desc(ComRecord.commit_date)).paginate(page=page, per_page=per_page, error_out=False)
        com_record_list = [comRecord.to_dict() for comRecord in comRecords.items]
        data = {
            "content_list": com_record_list,
            "page_list": getpages(page, per_page, comRecords.total),
            "cur_page": str(page),
            "content_total": str(comRecords.total),
            "view_name" : "myview.commitList",
        }
        return data