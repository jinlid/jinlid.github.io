import math

def getpages(cur_page=1, per_page=10, counts=0):
    page_list = ['1']
    max_page = math.ceil(counts / per_page)
    if max_page <= 5:
        page_list = [str(i) for i in range(1, max_page + 1)]
    else:
        cur_list = [str(i) for i in range(cur_page - 2, cur_page + 3) if i in range(2, max_page)]
        if (int(cur_list[0]) > 2):
            page_list.extend(['...'])
        page_list.extend(cur_list)
        if (int(cur_list[-1]) <= max_page - 2):
            page_list.extend(['...'])
        page_list.extend([str(max_page)])
    if cur_page > 1:
        page_list.insert(0, '<')
    if cur_page < max_page:
        page_list.append('>')
    return page_list

