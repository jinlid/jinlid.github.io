from github import Github

# 使用 GitHub API Token 进行认证（可选）
g = Github()  # 无认证会有限制，如果需要高频请求，可以使用你的 token

# 获取 repository 对象
repo = g.get_repo("postgres/postgres")

# 获取提交记录
commits = repo.get_commits(sha="master")

for commit in commits:
    commit_sha = commit.sha
    commit_message = commit.commit.message
    commit_author = commit.commit.author.name
    commit_date = commit.commit.author.date

    # 打印提交信息
    print(f"Commit: {commit_sha}")
    print(f"Message: {commit_message}")
    print(f"Author: {commit_author}")
    print(f"Date: {commit_date}")
    print('-' * 80)