import requests
import datetime

# 假设我们存储了上次采集时间
last_checked_time = datetime.datetime(2024, 12, 28, 0, 0, 0)


def get_commits_since_last_check():
    global last_checked_time  # 声明 last_checked_time 为全局变量
    url = "https://api.github.com/repos/postgres/postgres/commits?sha=master"

    # 添加参数过滤，只获取自上次检查以来的提交记录
    params = {'since': last_checked_time.isoformat()}
    response = requests.get(url, params=params)


    print(response.url)


# 每次调用时，检查并获取新的提交
get_commits_since_last_check()
