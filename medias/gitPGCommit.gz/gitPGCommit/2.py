import requests
import json

# GitHub API URL，用于获取提交记录
url = "https://api.github.com/repos/postgres/postgres/commits?sha=master"

# 发送请求
response = requests.get(url)

# 检查请求是否成功
if response.status_code == 200:
    commits = response.json()

    for commit in commits:
        commit_sha = commit['sha']
        commit_message = commit['commit']['message']
        commit_author = commit['commit']['author']['name']
        commit_date = commit['commit']['author']['date']
        commit_html_url = commit['html_url']

        # 打印提交信息
        print(f"Commit: {commit_sha}")
        print(f"Message: {commit_message}")
        print(f"Author: {commit_author}")
        print(f"Date: {commit_date}")
        print(f"html_url: {commit_html_url}")
        print('-' * 80)
else:
    print(f"Failed to retrieve the commits. Status code: {response.status_code}")